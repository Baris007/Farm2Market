﻿namespace UserRepository
{
    public class Class1
    {

    }
}
